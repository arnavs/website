using LinearAlgebra, ProgressMeter

# Population class and constructor
struct Population{T1, T2, T3}
    typeList::T1
    uMatrix::T2
    cMatrix::T3
    size::Integer
    nContracts::Integer
end 

function population(dist, size, contracts, u, c)
    typeList = [dist() for i in 1:size];
    nContracts = length(contracts);
    uMatrix = [u(type, contract) for type in typeList, contract in contracts]
    cMatrix = [c(type, contract) for type in typeList, contract in contracts]
    return Population(typeList, uMatrix, cMatrix, size, nContracts)
end

# merge two populations
function merge(p1::Population, p2::Population)
    @assert p1.nContracts == p2.nContracts # need to have same contracts
    nContracts = p1.nContracts
    size = p1.size + p2.size 
    typeList = [p1.typeList..., p2.typeList...]
    uMatrix = vcat(p1.uMatrix, p2.uMatrix)
    cMatrix = vcat(p1.cMatrix, p2.cMatrix)
    return Population(typeList, uMatrix, cMatrix, size, nContracts)
end

# population meth.ods
function demand(pop::Population, price)
    surplus = pop.uMatrix - repeat(price', pop.size);
    tmp, choiceVector = [findmax(row)[2] for row in eachrow(surplus)]; # find each agent's choice
    D = zeros(pop.nContracts);
    TC = similar(D);
    CS = similar(D); # pre-allocation of similar values
    for i in 1:pop.nContracts
        D[i] = sum(choiceVector .== i)/pop.size 
        TC[i] = sum(pop.cMatrix[findall(choiceVector .== i), i])/pop.size
        CS[i] = sum(surplus[findall(choiceVector .== i), i])/pop.size
    end
    CS = sum(CS)
    return (D = D, TC = TC, CS = CS, choiceVector = choiceVector)
end

function welfare(pop::Population, price, costOfPublicFunds)
    @unpack D, TC, CS = demand(pop, price)
    return CS + (1 + costOfPublicFunds) .* (D * price' - sum(TC))
end

function equilibrium(pop::Population;
                        behavioralAgents = 0.01, # set defaults per Azvezedo MATLAB code
                        fudge = 10^(-3),
                        tolerance = 10,
                        maxIterations = 10^6)
                        
    ϵ = behavioralAgents/pop.nContracts; # behavioral agents per contract 
    error = Inf;
    nIterations = 0;

    function iteration(p0)
        @unpack D, TC = demand(pop, p0);
        AC = TC ./ (D .+ ϵ);
        error = norm(AC - p0, Inf) 
        currentFudge = fudge + 1.1^(-nIterations -1) # update adaptive learning weight
        p1 = currentFudge * AC + (1 - currentFudge)*p0 # adaptive learning
        return (p = p1, error = error)
    end

    p = zeros(pop.nContracts)
    prog = Progress(maxIterations, 1)   # minimum update interval: 1 second

    while (error > tolerance && nIterations < maxIterations)
        @unpack p, error = iteration(p)
        # Require at least 50 iterations.
        if (nIterations < 50)
            error = Inf;
        end
        nIterations += 1;
        next!(prog)
    end

    return (p = p, error = error)
end
