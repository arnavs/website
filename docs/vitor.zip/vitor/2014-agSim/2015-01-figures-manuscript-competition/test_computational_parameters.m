clear;
addpath('../agSim');
rng(1);

% Input model parameters
meanS = sqrt(25000^2 - 5100^2);
typeDistributionMean = ...
    [1*10^(-5), 1330, 4340, meanS]; % Original A was 1.9*10^-3
typeDistributionLogCovariance = ...
    [ 0.25 -0.01 -0.12 0    ; % c11 = 0.25 originally
     -0.01  0.28 -0.03 0    ; % c22 = 0.98 originally
     -0.12 -0.03  0.20 0    ; % c33 = 0.20 originally
      0     0     0    0.25]; % ???
  
costOfPublicFunds = 0;

slopeVector            = 0:0.04:1;

% Calculation parameters
populationSize = 10^4;

CalculationParametersEquilibrium.behavioralAgents = 0.01;
CalculationParametersEquilibrium.fudge            = 10^(-3);
CalculationParametersEquilibrium.maxIterations    = 10^5;
CalculationParametersEquilibrium.tolerance        = 10;

CalculationParametersOptimum.maxIterations        = 10^5;
CalculationParametersOptimum.tolerance            = 0.01;

% List of parameters
fudgeVector = 10.^-linspace(2,5.5,10);

% Set model
Model = healthcaralognormalmodel(slopeVector, typeDistributionMean, typeDistributionLogCovariance);

Population = population(Model, populationSize);


% Loop
Results = cell(4,1);
for i = 1 : length(fudgeVector)
    Results{i}.CalculationParametersEquilibrium = CalculationParametersEquilibrium;
    Results{i}.CalculationParametersEquilibrium.fudge = fudgeVector(i);
    [~, ~, ~, ComputationOutputEquilibrium] = ...
        Population.findequilibrium(Results{i}.CalculationParametersEquilibrium);
    Results{i}.ComputationOutputEquilibrium = ComputationOutputEquilibrium;
    
%     [~, ~, ComputationOutputEfficient] = ...
%         findefficient(Population, costOfPublicFunds, Results{i}.CalculationParametersOptimum);
%     Results{i}.ComputationOutputEfficient = ComputationOutputEfficient;
end;

% Large pop loop
clear Population;
Population = population(Model, 10*populationSize);
ResultsLargePop = cell(4,1);
for i = 1 : length(fudgeVector)
    ResultsLargePop{i}.CalculationParametersEquilibrium = CalculationParametersEquilibrium;
    ResultsLargePop{i}.CalculationParametersEquilibrium.fudge = fudgeVector(i);
    [~, ~, ~, ComputationOutputEquilibrium] = ...
        Population.findequilibrium(ResultsLargePop{i}.CalculationParametersEquilibrium);
    ResultsLargePop{i}.ComputationOutputEquilibrium = ComputationOutputEquilibrium;
    
%     [~, ~, ComputationOutputEfficient] = ...
%         findefficient(Population, costOfPublicFunds, ResultsLargePop{i}.CalculationParametersOptimum);
%     ResultsLargePop{i}.ComputationOutputEfficient = ComputationOutputEfficient;
end;

clear Population;

save('test_computational_parameters');