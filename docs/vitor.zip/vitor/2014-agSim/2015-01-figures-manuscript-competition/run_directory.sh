#!/bin/bash

matlab -nodisplay < calculations.m

ssh unix.wharton.upenn.edu 'dropbox stop; sleep 20; dropbox start'
ssh unix.wharton.upenn.edu 'dropbox stop; sleep 20; dropbox start'
