#!/bin/bash

matlab -nodisplay < test_computational_parameters.m

ssh unix.wharton.upenn.edu 'dropbox stop; sleep 20; dropbox start'
ssh unix.wharton.upenn.edu 'dropbox stop; sleep 20; dropbox start'
