clear;
addpath('../agSim');
rng(1);

% Input model parameters
meanS = sqrt(25000^2 - 5100^2);
typeDistributionMean = ...
    [1*10^(-5), 1330, 4340, meanS]; % Original A was 1.9*10^-3 [A, H, M ,S]
typeDistributionLogCovariance = ...
    [ 0.25 0 0 0    ; 
      0 0.28 0 0    ; 
      0 0 0.20 0    ; 
      0 0 0    0.25]; 
  
costOfPublicFunds = 0;

% Calculation parameters
populationSize = 10^2;

CalculationParametersEquilibrium.behavioralAgents = 0.01;
CalculationParametersEquilibrium.fudge            = 10^(-3);
CalculationParametersEquilibrium.maxIterations    = 10^5;
CalculationParametersEquilibrium.tolerance        = 10;

CalculationParametersOptimum.maxIterations        = 10^3;
CalculationParametersOptimum.tolerance            = 0.01;

% List of models
modelName{1}              = 'interval';
slopeVector{1}            = 0:0.04:1;
moralHazardLogVariance{1} = 0.28;

% modelName{2}              = 'mandate';
% slopeVector{2}            = 0.60:0.04:1;
% moralHazardLogVariance{2} = 0.28;
% 
% modelName{3}              = 'interval_high_mh_variance';
% slopeVector{3}            = 0:0.04:1;
% moralHazardLogVariance{3} = 0.98;
% 
% modelName{4}              = 'mandate_high_mh_variance';
% slopeVector{4}            = 0.60:0.04:1;
% moralHazardLogVariance{4} = 0.98;

% Loop
for i = 1 : length(modelName)
    typeDistributionLogCovariance(2, 2) = moralHazardLogVariance{i};
    Model = healthcaralognormalmodel(slopeVector{i}, typeDistributionMean, typeDistributionLogCovariance);
    
    Population = population(Model, populationSize);
    
    [pEquilibrium, DEquilibrium, ACEquilibrium, ComputationOutputEquilibrium] = ...
        Population.findequilibrium(CalculationParametersEquilibrium);
    WEquilibrium = Population.welfare(pEquilibrium, costOfPublicFunds);
    
    [pEfficient, WEfficient, ComputationOutputEfficient] = ...
        findefficient(Population, costOfPublicFunds, CalculationParametersOptimum);
    DEfficient = Population.demand(pEfficient);
        
    save(modelName{i});
        
    display(modelName{i});
    display(ComputationOutputEquilibrium);
    display(ComputationOutputEfficient);
end;